class BaseError{
  final String? message;
  BaseError({
    required this.message,
  });
}
