import 'package:get_it/get_it.dart';

final locator = GetIt.instance;

Future<void> init() async {
 // locator.registerLazySingleton(() => AuthService(client))
}
