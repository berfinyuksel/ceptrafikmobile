class HttpConfig {
  HttpConfig._();
  static const int receiveTimeout = 15000;
  static const int connectionTimeout = 15000;
}