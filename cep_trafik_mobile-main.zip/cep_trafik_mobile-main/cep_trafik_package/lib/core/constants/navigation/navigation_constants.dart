class NavigationConstants {
  static const DEFAULT = '/';
  static const SAMPLE = 'sample';
  static const LOGIN_VIEW = '/login';
  static const HOME = '/home';
  static const MAP_VIEW = '/map';
  static const SETTINGS_VIEW = '/settingsView';
}
