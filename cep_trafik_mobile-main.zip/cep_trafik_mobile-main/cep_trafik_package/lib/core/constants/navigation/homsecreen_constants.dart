enum MapScreenConstants {
  MAP_VIEW,
  FAVORITES_VIEW,
  SETTINGS_VIEW,
}

// extension HomeScreenRouteNamesExtension on HomeScreenConstantsEnum {
//   Widget get rawValue {
//     switch (this) {
//       case HomeScreenConstantsEnum.MAP_VIEW:
//         return const SearchView();
//       case HomeScreenConstantsEnum.FAVORITES_VIEW:
//         return const FavoritesView();
//       case HomeScreenConstantsEnum.SETTINGS_VIEW:
//         return const SettingsView();
//     }
//   }
// }
