enum LocalDatabaseConstants { ispark, isbike, favorites, sample }
