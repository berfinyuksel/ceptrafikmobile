enum SharedPrefKeys { TOKEN, DARKMODE,LOGIN, TITLE }
